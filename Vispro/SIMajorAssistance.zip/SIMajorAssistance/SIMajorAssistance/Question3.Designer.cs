﻿namespace SIMajorAssistance
{
    partial class Question3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblheader = new System.Windows.Forms.Label();
            this.lblmatkul1 = new System.Windows.Forms.Label();
            this.txbmatkul1 = new System.Windows.Forms.TextBox();
            this.checkmatkul1 = new System.Windows.Forms.CheckBox();
            this.checkmatkul2 = new System.Windows.Forms.CheckBox();
            this.txbmatkul2 = new System.Windows.Forms.TextBox();
            this.lblmatkul2 = new System.Windows.Forms.Label();
            this.checkmatkul3 = new System.Windows.Forms.CheckBox();
            this.txbmatkul3 = new System.Windows.Forms.TextBox();
            this.lblmatkul3 = new System.Windows.Forms.Label();
            this.checkmatkul4 = new System.Windows.Forms.CheckBox();
            this.txbmatkul4 = new System.Windows.Forms.TextBox();
            this.lblmatkul4 = new System.Windows.Forms.Label();
            this.lblketerangan = new System.Windows.Forms.Label();
            this.lblpagenumber = new System.Windows.Forms.Label();
            this.btnnext = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblheader
            // 
            this.lblheader.AutoSize = true;
            this.lblheader.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblheader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblheader.Location = new System.Drawing.Point(16, 48);
            this.lblheader.Name = "lblheader";
            this.lblheader.Size = new System.Drawing.Size(73, 24);
            this.lblheader.TabIndex = 1;
            this.lblheader.Text = "Header";
            // 
            // lblmatkul1
            // 
            this.lblmatkul1.AutoSize = true;
            this.lblmatkul1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblmatkul1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblmatkul1.Location = new System.Drawing.Point(16, 88);
            this.lblmatkul1.Name = "lblmatkul1";
            this.lblmatkul1.Size = new System.Drawing.Size(344, 24);
            this.lblmatkul1.TabIndex = 11;
            this.lblmatkul1.Text = "IS 534 -Mobile Application Development";
            // 
            // txbmatkul1
            // 
            this.txbmatkul1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txbmatkul1.Location = new System.Drawing.Point(24, 128);
            this.txbmatkul1.Name = "txbmatkul1";
            this.txbmatkul1.Size = new System.Drawing.Size(128, 29);
            this.txbmatkul1.TabIndex = 1;
            // 
            // checkmatkul1
            // 
            this.checkmatkul1.AutoSize = true;
            this.checkmatkul1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmatkul1.Location = new System.Drawing.Point(160, 136);
            this.checkmatkul1.Name = "checkmatkul1";
            this.checkmatkul1.Size = new System.Drawing.Size(135, 20);
            this.checkmatkul1.TabIndex = 13;
            this.checkmatkul1.Text = "Belum mengambil";
            this.checkmatkul1.UseVisualStyleBackColor = true;
            // 
            // checkmatkul2
            // 
            this.checkmatkul2.AutoSize = true;
            this.checkmatkul2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmatkul2.Location = new System.Drawing.Point(160, 232);
            this.checkmatkul2.Name = "checkmatkul2";
            this.checkmatkul2.Size = new System.Drawing.Size(135, 20);
            this.checkmatkul2.TabIndex = 16;
            this.checkmatkul2.Text = "Belum mengambil";
            this.checkmatkul2.UseVisualStyleBackColor = true;
            // 
            // txbmatkul2
            // 
            this.txbmatkul2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txbmatkul2.Location = new System.Drawing.Point(24, 224);
            this.txbmatkul2.Name = "txbmatkul2";
            this.txbmatkul2.Size = new System.Drawing.Size(128, 29);
            this.txbmatkul2.TabIndex = 2;
            // 
            // lblmatkul2
            // 
            this.lblmatkul2.AutoSize = true;
            this.lblmatkul2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblmatkul2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblmatkul2.Location = new System.Drawing.Point(16, 184);
            this.lblmatkul2.Name = "lblmatkul2";
            this.lblmatkul2.Size = new System.Drawing.Size(212, 24);
            this.lblmatkul2.TabIndex = 14;
            this.lblmatkul2.Text = "IS 545 -Data Warehouse";
            // 
            // checkmatkul3
            // 
            this.checkmatkul3.AutoSize = true;
            this.checkmatkul3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmatkul3.Location = new System.Drawing.Point(160, 336);
            this.checkmatkul3.Name = "checkmatkul3";
            this.checkmatkul3.Size = new System.Drawing.Size(135, 20);
            this.checkmatkul3.TabIndex = 19;
            this.checkmatkul3.Text = "Belum mengambil";
            this.checkmatkul3.UseVisualStyleBackColor = true;
            // 
            // txbmatkul3
            // 
            this.txbmatkul3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txbmatkul3.Location = new System.Drawing.Point(24, 328);
            this.txbmatkul3.Name = "txbmatkul3";
            this.txbmatkul3.Size = new System.Drawing.Size(128, 29);
            this.txbmatkul3.TabIndex = 3;
            // 
            // lblmatkul3
            // 
            this.lblmatkul3.AutoSize = true;
            this.lblmatkul3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblmatkul3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblmatkul3.Location = new System.Drawing.Point(16, 288);
            this.lblmatkul3.Name = "lblmatkul3";
            this.lblmatkul3.Size = new System.Drawing.Size(335, 24);
            this.lblmatkul3.TabIndex = 17;
            this.lblmatkul3.Text = "IS 556 - Web Design and Development";
            // 
            // checkmatkul4
            // 
            this.checkmatkul4.AutoSize = true;
            this.checkmatkul4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmatkul4.Location = new System.Drawing.Point(608, 136);
            this.checkmatkul4.Name = "checkmatkul4";
            this.checkmatkul4.Size = new System.Drawing.Size(135, 20);
            this.checkmatkul4.TabIndex = 22;
            this.checkmatkul4.Text = "Belum mengambil";
            this.checkmatkul4.UseVisualStyleBackColor = true;
            // 
            // txbmatkul4
            // 
            this.txbmatkul4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txbmatkul4.Location = new System.Drawing.Point(472, 128);
            this.txbmatkul4.Name = "txbmatkul4";
            this.txbmatkul4.Size = new System.Drawing.Size(128, 29);
            this.txbmatkul4.TabIndex = 4;
            // 
            // lblmatkul4
            // 
            this.lblmatkul4.AutoSize = true;
            this.lblmatkul4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblmatkul4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblmatkul4.Location = new System.Drawing.Point(464, 88);
            this.lblmatkul4.Name = "lblmatkul4";
            this.lblmatkul4.Size = new System.Drawing.Size(343, 24);
            this.lblmatkul4.TabIndex = 20;
            this.lblmatkul4.Text = "IS 588 - Security and Computer Network";
            // 
            // lblketerangan
            // 
            this.lblketerangan.AutoSize = true;
            this.lblketerangan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblketerangan.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblketerangan.Location = new System.Drawing.Point(472, 168);
            this.lblketerangan.Name = "lblketerangan";
            this.lblketerangan.Size = new System.Drawing.Size(331, 16);
            this.lblketerangan.TabIndex = 23;
            this.lblketerangan.Text = "dulu dikenal dengan nama CE 441 - Computer Network";
            // 
            // lblpagenumber
            // 
            this.lblpagenumber.AutoSize = true;
            this.lblpagenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpagenumber.ForeColor = System.Drawing.Color.Red;
            this.lblpagenumber.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblpagenumber.Location = new System.Drawing.Point(16, 16);
            this.lblpagenumber.Name = "lblpagenumber";
            this.lblpagenumber.Size = new System.Drawing.Size(107, 16);
            this.lblpagenumber.TabIndex = 33;
            this.lblpagenumber.Text = "Question Page 3";
            // 
            // btnnext
            // 
            this.btnnext.BackgroundImage = global::SIMajorAssistance.Properties.Resources.next;
            this.btnnext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnnext.FlatAppearance.BorderSize = 0;
            this.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnnext.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnnext.Location = new System.Drawing.Point(776, 400);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(50, 50);
            this.btnnext.TabIndex = 8;
            this.btnnext.UseVisualStyleBackColor = true;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.White;
            this.btnclose.BackgroundImage = global::SIMajorAssistance.Properties.Resources.close;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.FlatAppearance.BorderSize = 0;
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnclose.Location = new System.Drawing.Point(792, 16);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(35, 35);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // btnback
            // 
            this.btnback.BackgroundImage = global::SIMajorAssistance.Properties.Resources.back;
            this.btnback.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnback.FlatAppearance.BorderSize = 0;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnback.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnback.Location = new System.Drawing.Point(712, 400);
            this.btnback.Name = "btnback";
            this.btnback.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnback.Size = new System.Drawing.Size(50, 50);
            this.btnback.TabIndex = 35;
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // Question3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(848, 480);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.lblpagenumber);
            this.Controls.Add(this.lblketerangan);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.checkmatkul4);
            this.Controls.Add(this.txbmatkul4);
            this.Controls.Add(this.lblmatkul4);
            this.Controls.Add(this.checkmatkul3);
            this.Controls.Add(this.txbmatkul3);
            this.Controls.Add(this.lblmatkul3);
            this.Controls.Add(this.checkmatkul2);
            this.Controls.Add(this.txbmatkul2);
            this.Controls.Add(this.lblmatkul2);
            this.Controls.Add(this.checkmatkul1);
            this.Controls.Add(this.txbmatkul1);
            this.Controls.Add(this.lblmatkul1);
            this.Controls.Add(this.lblheader);
            this.Controls.Add(this.btnclose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Question3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Question1";
            this.Load += new System.EventHandler(this.Questionform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Label lblheader;
        private System.Windows.Forms.Label lblmatkul1;
        private System.Windows.Forms.TextBox txbmatkul1;
        private System.Windows.Forms.CheckBox checkmatkul1;
        private System.Windows.Forms.CheckBox checkmatkul2;
        private System.Windows.Forms.TextBox txbmatkul2;
        private System.Windows.Forms.Label lblmatkul2;
        private System.Windows.Forms.CheckBox checkmatkul3;
        private System.Windows.Forms.TextBox txbmatkul3;
        private System.Windows.Forms.Label lblmatkul3;
        private System.Windows.Forms.CheckBox checkmatkul4;
        private System.Windows.Forms.TextBox txbmatkul4;
        private System.Windows.Forms.Label lblmatkul4;
        private System.Windows.Forms.Button btnnext;
        private System.Windows.Forms.Label lblketerangan;
        private System.Windows.Forms.Label lblpagenumber;
        private System.Windows.Forms.Button btnback;
    }
}