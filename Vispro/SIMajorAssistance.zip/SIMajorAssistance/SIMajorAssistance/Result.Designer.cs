﻿namespace SIMajorAssistance
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpagenumber = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.lblstatement1 = new System.Windows.Forms.Label();
            this.lblstatement3 = new System.Windows.Forms.Label();
            this.lblstatement2 = new System.Windows.Forms.Label();
            this.lblnama = new System.Windows.Forms.Label();
            this.lblspt1 = new System.Windows.Forms.Label();
            this.lblspt3 = new System.Windows.Forms.Label();
            this.lblspt2 = new System.Windows.Forms.Label();
            this.lblnim = new System.Windows.Forms.Label();
            this.lblangkatan = new System.Windows.Forms.Label();
            this.lblketerangan = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lblhasil1 = new System.Windows.Forms.Label();
            this.lblhasil2 = new System.Windows.Forms.Label();
            this.lblhasil3 = new System.Windows.Forms.Label();
            this.lblhasil4 = new System.Windows.Forms.Label();
            this.btnfinish = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpagenumber
            // 
            this.lblpagenumber.AutoSize = true;
            this.lblpagenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpagenumber.ForeColor = System.Drawing.Color.Red;
            this.lblpagenumber.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblpagenumber.Location = new System.Drawing.Point(16, 16);
            this.lblpagenumber.Name = "lblpagenumber";
            this.lblpagenumber.Size = new System.Drawing.Size(46, 16);
            this.lblpagenumber.TabIndex = 33;
            this.lblpagenumber.Text = "Result";
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.White;
            this.btnclose.BackgroundImage = global::SIMajorAssistance.Properties.Resources.close;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.FlatAppearance.BorderSize = 0;
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnclose.Location = new System.Drawing.Point(792, 16);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(35, 35);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lblstatement1
            // 
            this.lblstatement1.AutoSize = true;
            this.lblstatement1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblstatement1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblstatement1.Location = new System.Drawing.Point(16, 48);
            this.lblstatement1.Name = "lblstatement1";
            this.lblstatement1.Size = new System.Drawing.Size(60, 24);
            this.lblstatement1.TabIndex = 34;
            this.lblstatement1.Text = "Nama";
            // 
            // lblstatement3
            // 
            this.lblstatement3.AutoSize = true;
            this.lblstatement3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblstatement3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblstatement3.Location = new System.Drawing.Point(16, 128);
            this.lblstatement3.Name = "lblstatement3";
            this.lblstatement3.Size = new System.Drawing.Size(89, 24);
            this.lblstatement3.TabIndex = 35;
            this.lblstatement3.Text = "Angkatan";
            // 
            // lblstatement2
            // 
            this.lblstatement2.AutoSize = true;
            this.lblstatement2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblstatement2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblstatement2.Location = new System.Drawing.Point(16, 88);
            this.lblstatement2.Name = "lblstatement2";
            this.lblstatement2.Size = new System.Drawing.Size(44, 24);
            this.lblstatement2.TabIndex = 36;
            this.lblstatement2.Text = "NIM";
            // 
            // lblnama
            // 
            this.lblnama.AutoSize = true;
            this.lblnama.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblnama.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblnama.Location = new System.Drawing.Point(184, 48);
            this.lblnama.Name = "lblnama";
            this.lblnama.Size = new System.Drawing.Size(57, 24);
            this.lblnama.TabIndex = 37;
            this.lblnama.Text = "nama";
            // 
            // lblspt1
            // 
            this.lblspt1.AutoSize = true;
            this.lblspt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblspt1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblspt1.Location = new System.Drawing.Point(152, 48);
            this.lblspt1.Name = "lblspt1";
            this.lblspt1.Size = new System.Drawing.Size(15, 24);
            this.lblspt1.TabIndex = 38;
            this.lblspt1.Text = ":";
            // 
            // lblspt3
            // 
            this.lblspt3.AutoSize = true;
            this.lblspt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblspt3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblspt3.Location = new System.Drawing.Point(152, 128);
            this.lblspt3.Name = "lblspt3";
            this.lblspt3.Size = new System.Drawing.Size(15, 24);
            this.lblspt3.TabIndex = 39;
            this.lblspt3.Text = ":";
            // 
            // lblspt2
            // 
            this.lblspt2.AutoSize = true;
            this.lblspt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblspt2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblspt2.Location = new System.Drawing.Point(152, 88);
            this.lblspt2.Name = "lblspt2";
            this.lblspt2.Size = new System.Drawing.Size(15, 24);
            this.lblspt2.TabIndex = 40;
            this.lblspt2.Text = ":";
            // 
            // lblnim
            // 
            this.lblnim.AutoSize = true;
            this.lblnim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblnim.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblnim.Location = new System.Drawing.Point(184, 88);
            this.lblnim.Name = "lblnim";
            this.lblnim.Size = new System.Drawing.Size(41, 24);
            this.lblnim.TabIndex = 41;
            this.lblnim.Text = "nim";
            // 
            // lblangkatan
            // 
            this.lblangkatan.AutoSize = true;
            this.lblangkatan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblangkatan.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblangkatan.Location = new System.Drawing.Point(184, 128);
            this.lblangkatan.Name = "lblangkatan";
            this.lblangkatan.Size = new System.Drawing.Size(86, 24);
            this.lblangkatan.TabIndex = 42;
            this.lblangkatan.Text = "angkatan";
            // 
            // lblketerangan
            // 
            this.lblketerangan.AutoSize = true;
            this.lblketerangan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblketerangan.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblketerangan.Location = new System.Drawing.Point(16, 192);
            this.lblketerangan.Name = "lblketerangan";
            this.lblketerangan.Size = new System.Drawing.Size(741, 24);
            this.lblketerangan.TabIndex = 43;
            this.lblketerangan.Text = "Berdasarkan data yang telah anda berikan, berikut adalah rekomendasi peminatan an" +
    "da";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lbl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl1.Location = new System.Drawing.Point(24, 232);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(25, 24);
            this.lbl1.TabIndex = 44;
            this.lbl1.Text = "1.";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lbl2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl2.Location = new System.Drawing.Point(24, 272);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(25, 24);
            this.lbl2.TabIndex = 45;
            this.lbl2.Text = "2.";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lbl3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl3.Location = new System.Drawing.Point(24, 312);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(25, 24);
            this.lbl3.TabIndex = 46;
            this.lbl3.Text = "3.";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lbl4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl4.Location = new System.Drawing.Point(24, 352);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(25, 24);
            this.lbl4.TabIndex = 47;
            this.lbl4.Text = "4.";
            // 
            // lblhasil1
            // 
            this.lblhasil1.AutoSize = true;
            this.lblhasil1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblhasil1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblhasil1.Location = new System.Drawing.Point(64, 232);
            this.lblhasil1.Name = "lblhasil1";
            this.lblhasil1.Size = new System.Drawing.Size(65, 24);
            this.lblhasil1.TabIndex = 48;
            this.lblhasil1.Text = "minat1";
            // 
            // lblhasil2
            // 
            this.lblhasil2.AutoSize = true;
            this.lblhasil2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblhasil2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblhasil2.Location = new System.Drawing.Point(64, 272);
            this.lblhasil2.Name = "lblhasil2";
            this.lblhasil2.Size = new System.Drawing.Size(65, 24);
            this.lblhasil2.TabIndex = 49;
            this.lblhasil2.Text = "minat2";
            // 
            // lblhasil3
            // 
            this.lblhasil3.AutoSize = true;
            this.lblhasil3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblhasil3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblhasil3.Location = new System.Drawing.Point(64, 312);
            this.lblhasil3.Name = "lblhasil3";
            this.lblhasil3.Size = new System.Drawing.Size(65, 24);
            this.lblhasil3.TabIndex = 50;
            this.lblhasil3.Text = "minat3";
            // 
            // lblhasil4
            // 
            this.lblhasil4.AutoSize = true;
            this.lblhasil4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblhasil4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblhasil4.Location = new System.Drawing.Point(64, 352);
            this.lblhasil4.Name = "lblhasil4";
            this.lblhasil4.Size = new System.Drawing.Size(65, 24);
            this.lblhasil4.TabIndex = 51;
            this.lblhasil4.Text = "minat4";
            // 
            // btnfinish
            // 
            this.btnfinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnfinish.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnfinish.Location = new System.Drawing.Point(728, 424);
            this.btnfinish.Name = "btnfinish";
            this.btnfinish.Size = new System.Drawing.Size(96, 40);
            this.btnfinish.TabIndex = 52;
            this.btnfinish.Text = "Finish";
            this.btnfinish.UseVisualStyleBackColor = true;
            this.btnfinish.Click += new System.EventHandler(this.btnfinish_Click);
            // 
            // btnreset
            // 
            this.btnreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnreset.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnreset.Location = new System.Drawing.Point(608, 424);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(96, 40);
            this.btnreset.TabIndex = 53;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = true;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(848, 480);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnfinish);
            this.Controls.Add(this.lblhasil4);
            this.Controls.Add(this.lblhasil3);
            this.Controls.Add(this.lblhasil2);
            this.Controls.Add(this.lblhasil1);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lblketerangan);
            this.Controls.Add(this.lblangkatan);
            this.Controls.Add(this.lblnim);
            this.Controls.Add(this.lblspt2);
            this.Controls.Add(this.lblspt3);
            this.Controls.Add(this.lblspt1);
            this.Controls.Add(this.lblnama);
            this.Controls.Add(this.lblstatement2);
            this.Controls.Add(this.lblstatement3);
            this.Controls.Add(this.lblstatement1);
            this.Controls.Add(this.lblpagenumber);
            this.Controls.Add(this.btnclose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Result";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.Resultform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Label lblpagenumber;
        private System.Windows.Forms.Label lblstatement1;
        private System.Windows.Forms.Label lblstatement3;
        private System.Windows.Forms.Label lblstatement2;
        private System.Windows.Forms.Label lblnama;
        private System.Windows.Forms.Label lblspt1;
        private System.Windows.Forms.Label lblspt3;
        private System.Windows.Forms.Label lblspt2;
        private System.Windows.Forms.Label lblnim;
        private System.Windows.Forms.Label lblangkatan;
        private System.Windows.Forms.Label lblketerangan;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lblhasil1;
        private System.Windows.Forms.Label lblhasil2;
        private System.Windows.Forms.Label lblhasil3;
        private System.Windows.Forms.Label lblhasil4;
        private System.Windows.Forms.Button btnfinish;
        private System.Windows.Forms.Button btnreset;
    }
}