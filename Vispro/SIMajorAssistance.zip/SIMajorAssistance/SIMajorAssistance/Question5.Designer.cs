﻿namespace SIMajorAssistance
{
    partial class Question5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpagenumber = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.btnnext = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.lblsoal1 = new System.Windows.Forms.Label();
            this.cmbbox1 = new System.Windows.Forms.ComboBox();
            this.cmbbox2 = new System.Windows.Forms.ComboBox();
            this.lblsoal2 = new System.Windows.Forms.Label();
            this.lblsoal3 = new System.Windows.Forms.Label();
            this.cmbbox3 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblpagenumber
            // 
            this.lblpagenumber.AutoSize = true;
            this.lblpagenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpagenumber.ForeColor = System.Drawing.Color.Red;
            this.lblpagenumber.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblpagenumber.Location = new System.Drawing.Point(16, 16);
            this.lblpagenumber.Name = "lblpagenumber";
            this.lblpagenumber.Size = new System.Drawing.Size(107, 16);
            this.lblpagenumber.TabIndex = 33;
            this.lblpagenumber.Text = "Question Page 5";
            // 
            // btnback
            // 
            this.btnback.BackgroundImage = global::SIMajorAssistance.Properties.Resources.back;
            this.btnback.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnback.FlatAppearance.BorderSize = 0;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnback.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnback.Location = new System.Drawing.Point(712, 400);
            this.btnback.Name = "btnback";
            this.btnback.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnback.Size = new System.Drawing.Size(50, 50);
            this.btnback.TabIndex = 34;
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnnext
            // 
            this.btnnext.BackgroundImage = global::SIMajorAssistance.Properties.Resources.next;
            this.btnnext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnnext.FlatAppearance.BorderSize = 0;
            this.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnnext.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnnext.Location = new System.Drawing.Point(776, 400);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(50, 50);
            this.btnnext.TabIndex = 8;
            this.btnnext.UseVisualStyleBackColor = true;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.White;
            this.btnclose.BackgroundImage = global::SIMajorAssistance.Properties.Resources.close;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.FlatAppearance.BorderSize = 0;
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnclose.Location = new System.Drawing.Point(792, 16);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(35, 35);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lblsoal1
            // 
            this.lblsoal1.AutoSize = true;
            this.lblsoal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblsoal1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblsoal1.Location = new System.Drawing.Point(16, 48);
            this.lblsoal1.Name = "lblsoal1";
            this.lblsoal1.Size = new System.Drawing.Size(279, 24);
            this.lblsoal1.TabIndex = 1;
            this.lblsoal1.Text = "Pilihan peminatan pertama anda";
            // 
            // cmbbox1
            // 
            this.cmbbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbox1.FormattingEnabled = true;
            this.cmbbox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbbox1.Items.AddRange(new object[] {
            "- Pilihan 1 -",
            "Big Data ",
            "Database (Oracle)",
            "Enterprise Resource Planning (SAP ERP)",
            "IT Governance (COBIT, ITIL, TOGAF)"});
            this.cmbbox1.Location = new System.Drawing.Point(24, 88);
            this.cmbbox1.Name = "cmbbox1";
            this.cmbbox1.Size = new System.Drawing.Size(456, 32);
            this.cmbbox1.TabIndex = 1;
            // 
            // cmbbox2
            // 
            this.cmbbox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbox2.FormattingEnabled = true;
            this.cmbbox2.Items.AddRange(new object[] {
            "- Pilihan 2 -",
            "Big Data ",
            "Database (Oracle)",
            "Enterprise Resource Planning (SAP ERP)",
            "IT Governance (COBIT, ITIL, TOGAF)"});
            this.cmbbox2.Location = new System.Drawing.Point(24, 208);
            this.cmbbox2.Name = "cmbbox2";
            this.cmbbox2.Size = new System.Drawing.Size(456, 32);
            this.cmbbox2.TabIndex = 2;
            // 
            // lblsoal2
            // 
            this.lblsoal2.AutoSize = true;
            this.lblsoal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblsoal2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblsoal2.Location = new System.Drawing.Point(16, 152);
            this.lblsoal2.Name = "lblsoal2";
            this.lblsoal2.Size = new System.Drawing.Size(263, 24);
            this.lblsoal2.TabIndex = 36;
            this.lblsoal2.Text = "Pilihan peminatan kedua anda";
            // 
            // lblsoal3
            // 
            this.lblsoal3.AutoSize = true;
            this.lblsoal3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblsoal3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblsoal3.Location = new System.Drawing.Point(16, 280);
            this.lblsoal3.Name = "lblsoal3";
            this.lblsoal3.Size = new System.Drawing.Size(415, 24);
            this.lblsoal3.TabIndex = 38;
            this.lblsoal3.Text = "Pilihlan salah satu pekerjaan yang anda inginkan";
            // 
            // cmbbox3
            // 
            this.cmbbox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbox3.FormattingEnabled = true;
            this.cmbbox3.Items.AddRange(new object[] {
            "- Pilihan 3 -",
            "Developer",
            "Database Administrator",
            "Auditor / System Audit",
            "Data Analyst",
            "IT Consultant"});
            this.cmbbox3.Location = new System.Drawing.Point(24, 336);
            this.cmbbox3.Name = "cmbbox3";
            this.cmbbox3.Size = new System.Drawing.Size(456, 32);
            this.cmbbox3.TabIndex = 37;
            // 
            // Question5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(848, 480);
            this.Controls.Add(this.lblsoal3);
            this.Controls.Add(this.cmbbox3);
            this.Controls.Add(this.lblsoal2);
            this.Controls.Add(this.cmbbox2);
            this.Controls.Add(this.cmbbox1);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.lblpagenumber);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.lblsoal1);
            this.Controls.Add(this.btnclose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Question5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.Questionform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btnnext;
        private System.Windows.Forms.Label lblpagenumber;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Label lblsoal1;
        private System.Windows.Forms.ComboBox cmbbox1;
        private System.Windows.Forms.ComboBox cmbbox2;
        private System.Windows.Forms.Label lblsoal2;
        private System.Windows.Forms.Label lblsoal3;
        private System.Windows.Forms.ComboBox cmbbox3;
    }
}